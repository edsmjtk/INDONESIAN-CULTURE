import "regenerator-runtime";
import "../styles/main.css";
import "../styles/responsive.css";

fetch("DATA.json")
  .then((response) => response.json())
  .then((data) => {
    restaurants(data);
  });

function restaurants(data) {
  let restaurantHTML = "";
  data.restaurants.forEach(function (restaurant) {
    restaurantHTML += `
      <div tabindex="0" class="card">
        <div class="img-container">
          <img tabindex="0" class="img-res" src="${restaurant.pictureId}" alt="${restaurant.name}"/>
          <span tabindex="0" class="card-title">${restaurant.name} - ${restaurant.city}</span>
        </div>
        <div tabindex="0" class="card-content">
          <p class="card-content-title">Description :</p>
          <p class="desc">${restaurant.description}</p>
        </div>
      </div>
      `;
  });

  document.getElementById("explore-content").innerHTML = restaurantHTML;
}

document.querySelector(".menu").addEventListener("click", function () {
  document.querySelector(".nav-list").classList.toggle("nav-list-block");
});

